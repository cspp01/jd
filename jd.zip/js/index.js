/**
 * Created by Administrator on 2017/1/11/011.
 */
$(function(){
    alert("2");
});
/**
 * Created by Administrator on 2017/1/11/011.
 */
$(function(){
    alert("1");
});